﻿Public Class Form1
    Declare Auto Function SendMessage Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Enum ProgressBarColor
        Green = &H1
        Red = &H2
        Yellow = &H3
    End Enum
    Private Shared Sub ChangeProgBarColor(ByVal ProgressBar_name As Windows.Forms.ProgressBar, ByVal ProgressBar_Color As ProgressBarColor)
        SendMessage(ProgressBar_name.Handle, &H410, ProgressBar_Color, 0)
    End Sub

    Dim sts As Integer = 0
    Dim install As Boolean = False

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If sts = 0 Then
            Button1.Enabled = False
            Label1.Text = "Downloading an update package... " + "0" + "%"
            Timer1.Start()
            install = True
        End If
        If sts = 1 Then
            ProgressBar1.Value = 0
            Label1.Text = "Installing security update... " + "0" + "%"
            Timer2.Start()
            Button1.Enabled = False
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(1)
        Label1.Text = "Downloading an update package... " + ProgressBar1.Value.ToString() + "%"
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            Label1.Text = "Click the button to install the update package."
            MsgBox("Updates have been successfully downloaded! Click OK to return to the Windows 10 Update Center and install them", MsgBoxStyle.Information, "Windows 10 Update Center")
            Button1.Text = "Install"
            sts = 1
            Button1.Enabled = True
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value <= 90 Then
            Label1.Text = "Installing security update... " + ProgressBar1.Value.ToString() + "%"
        End If
        If ProgressBar1.Value > 90 Then
            If ProgressBar1.Value = 100 Then
                Timer2.Stop()
                System.Threading.Thread.Sleep(1100)
                Label1.Text = "Cleaning temponary files... " + "100" + "%"
                MsgBox("A critical error has occured, and the installation has been stopped to prevent the damage to the system. Please try again later. Dont shutdown or restart your computer.", MsgBoxStyle.Critical, "Windows 10 Update Center - Error")
                Timer3.Start()
            End If
            Label1.Text = "Cleaning temponary files... " + ProgressBar1.Value.ToString() + "%"
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If ProgressBar1.Value > 0 Then
            ChangeProgBarColor(ProgressBar1, ProgressBarColor.Red)
            ProgressBar1.Increment(-1)
            Label1.Text = "Reverting changes... "
        End If
        If ProgressBar1.Value = 0 Then
            Timer3.Stop()
            ChangeProgBarColor(ProgressBar1, ProgressBarColor.Green)
            Label1.Text = "Click the button to start the download"
            Button1.Text = "Download"
            Button1.Enabled = True
            install = False
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RichTextBox1.Find("%date%", 0, RichTextBoxFinds.None)
        RichTextBox1.Focus()
        If Date.Now.Month <= 9 Then
            RichTextBox1.SelectedText = "0" + Date.Now.Month.ToString() + "/" + Date.Now.Year.ToString()
        End If
        If Date.Now.Month > 9 Then
            RichTextBox1.SelectedText = Date.Now.Month.ToString() + "/" + Date.Now.Year.ToString()
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If install = True Then
            If e.CloseReason = CloseReason.TaskManagerClosing Then
                e.Cancel = True
            ElseIf e.CloseReason = CloseReason.ApplicationExitCall Then
                e.Cancel = True
            ElseIf e.CloseReason = CloseReason.WindowsShutDown Then
                e.Cancel = True
                Shell("cmd.exe /k" & vbCrLf & "shutdown -a")
                MsgBox("You cannot shut down the system while installing", MsgBoxStyle.Exclamation, "Windows 10 Update Center")
            ElseIf e.CloseReason = CloseReason.UserClosing Then
                e.Cancel = True
                MsgBox("You cannot close the application while installing", MsgBoxStyle.Exclamation, "Windows 10 Update Center")
            ElseIf e.CloseReason = CloseReason.None Then
                e.Cancel = True
            End If
        End If
    End Sub
End Class
